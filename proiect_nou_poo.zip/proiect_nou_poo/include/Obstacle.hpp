#pragma once
#include <SFML/Graphics.hpp>

enum class ObstacleType { Fire, Water, Green };

class Obstacle {
private:
    sf::RectangleShape shape;
    ObstacleType type;
    sf::Vector2f position;
    sf::FloatRect hitbox;

public:
    Obstacle(float x, float y, float width, float height, const sf::Texture& texture, ObstacleType type);

    void draw(sf::RenderWindow& window);
    sf::FloatRect getBounds() const;

    ObstacleType getType() const;
};