    #ifndef CHARACTER_HPP
    #define CHARACTER_HPP

    #include <SFML/Graphics.hpp>
    #include <vector>
    #include "Platform.hpp"

    class Character {
    protected:
        sf::Sprite sprite;
        sf::Texture texture;
        sf::Vector2f velocity;
        bool onGround;
        float moveSpeed;
        float jumpSpeed;
        sf::Vector2f startPosition; // ✅ Poziția inițială

    public:
        Character();
        virtual ~Character() = default;

        virtual void handleInput() = 0;
        virtual void update(float deltaTime, const std::vector<Platform<float>>& platforms);
        virtual void draw(sf::RenderWindow& window);

        void applyGravity(float deltaTime, const std::vector<Platform<float>>& platforms);
        void setPosition(float x, float y);
        sf::Vector2f getPosition() const;
        sf::FloatRect getPositionRect() const;

        // Apelezi asta o singură dată, la inițializare:
        void setStartPosition(float x, float y);


        void resetPosition(); // ✅ Resetare la poziția inițială
        bool hasFallen() const;

        // **Nou:** mută personajul cu o deplasare dată (ex: vector delta)
        void move(float dx, float dy);
        
    };

    #endif // CHARACTER_HPP