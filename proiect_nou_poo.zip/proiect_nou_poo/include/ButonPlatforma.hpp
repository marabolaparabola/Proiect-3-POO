#pragma once
#include <SFML/Graphics.hpp>

class ButonPlatforma {
private:
    sf::RectangleShape shape;
    bool pressed;  // dacă butonul este apăsat

public:
    ButonPlatforma(float x, float y, float width, float height, const sf::Texture& texture);

    void draw(sf::RenderWindow& window) const;

    // Setează dacă butonul este apăsat sau nu
    void setPressed(bool isPressed);
    bool isPressed() const;

    // Verifică dacă un dreptunghi (personajul) apasă pe buton
    bool checkPressed(const sf::FloatRect& entityBounds);
    sf::FloatRect getBounds() const;

};