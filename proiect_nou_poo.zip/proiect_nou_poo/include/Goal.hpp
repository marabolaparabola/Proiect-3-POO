#ifndef GOAL_HPP 
#define GOAL_HPP

#include <SFML/Graphics.hpp>
#include "Character.hpp"
#include <vector>

class Goal {
private:
    sf::Sprite sprite;
    sf::Texture texture;
    std::vector<sf::IntRect> frames;
    std::size_t currentFrame;
    float animationTimer;
    float animationSpeed; // secunde per frame
    bool isOpening;
    bool isForFireboy;

public:
    Goal(bool forFireboy, float x, float y);

    void draw(sf::RenderWindow& window) const;
    void update(float deltaTime);
    bool checkCollision(const Character& character);
    bool isOpeningFinished() const;

    sf::Vector2f getPosition() const;
    sf::FloatRect getBounds() const;
    void setPosition(float x, float y); // 🔧 ADĂUGAT
};

#endif // GOAL_HPP
