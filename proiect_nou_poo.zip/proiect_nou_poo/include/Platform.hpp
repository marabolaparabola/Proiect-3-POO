#pragma once
#include <SFML/Graphics.hpp>

// Clasă template
template<typename T>
class Platform {
protected:
    sf::RectangleShape shape;
    T scaleFactor; // atribut de tip T

public:
    Platform(T x, T y, T width, T height, const sf::Texture& texture, bool hasOutline = true)
        : scaleFactor(1) // default
    {
        shape.setPosition(static_cast<float>(x), static_cast<float>(y));
        shape.setSize(sf::Vector2f(static_cast<float>(width), static_cast<float>(height)));
        shape.setTexture(&texture);
        shape.setTextureRect(sf::IntRect(0, 0, static_cast<int>(width), static_cast<int>(height)));

        if (hasOutline) {
            shape.setOutlineColor(sf::Color::Black);
            shape.setOutlineThickness(1.f);
        } else {
            shape.setOutlineThickness(0.f);
        }
    }

    void draw(sf::RenderWindow& window) const {
        window.draw(shape);
    }

    const sf::FloatRect getBounds() const {
        return shape.getGlobalBounds();
    }

    void move(T dx, T dy) {
        shape.move(static_cast<float>(dx), static_cast<float>(dy));
    }

    void setPosition(T x, T y) {
        shape.setPosition(static_cast<float>(x), static_cast<float>(y));
    }

    sf::Vector2f getPosition() const {
        return shape.getPosition();
    }

    sf::Vector2f getSize() const {
        return shape.getSize();
    }

    void scale(T factor) {
        scaleFactor = factor;
        shape.setScale(static_cast<float>(factor), static_cast<float>(factor));
    }

    T getScaleFactor() const {
        return scaleFactor;
    }

    // ✅ Funcția prietenă template
    template<typename U>
    friend U computeArea(const Platform<U>& p);
};

// ✅ Funcție liberă template (poate fi și friend)
template<typename T>
T computeArea(const Platform<T>& p) {
    sf::Vector2f size = p.getSize();
    return static_cast<T>(size.x * size.y);
}
