#ifndef GAMEOBJECT_HPP
#define GAMEOBJECT_HPP

#include <SFML/Graphics.hpp>
#include "Character.hpp"

class GameObject {
public:
    virtual ~GameObject() = default;

    // Desenare în fereastră
    virtual void draw(sf::RenderWindow& window) const = 0;

    // Returnează dreptunghiul obiectului pentru coliziuni/detecție
    virtual sf::FloatRect getBounds() const = 0;

    // Funcție virtuală specifică temei: interacțiune cu personajul
    // Pentru ușă, buton, platformă, etc.
    virtual void interact(Character& character) = 0;
};

#endif // GAMEOBJECT_HPP