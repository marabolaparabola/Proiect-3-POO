#ifndef FIREBOY_HPP
#define FIREBOY_HPP

#include "Character.hpp"

class Fireboy : public Character {
public:
    Fireboy();

    void handleInput() override;

    float getHeight() const;
};

#endif // FIREBOY_HPP