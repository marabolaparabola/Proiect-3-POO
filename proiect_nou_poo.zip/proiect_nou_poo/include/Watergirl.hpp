#ifndef WATERGIRL_HPP
#define WATERGIRL_HPP

#include "Character.hpp"

class Watergirl : public Character {
public:
    Watergirl();

    void handleInput() override;

    float getHeight() const;
    

};

#endif // WATERGIRL_HPP
