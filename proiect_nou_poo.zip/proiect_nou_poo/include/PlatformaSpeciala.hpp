#ifndef PLATFORMA_SPECIALA_HPP
#define PLATFORMA_SPECIALA_HPP

#include "Platform.hpp"
#include <SFML/Graphics.hpp>

class PlatformaSpeciala : public Platform<float> {
private:
    float moveSpeed;   // viteza de mișcare
    float startY;      // poziția inițială pe axa Y
    float maxLift;     // cât să urce maxim
    sf::Vector2f oldPosition;  // poziția din frame-ul anterior

public:
    PlatformaSpeciala(float x, float y, float width, float height,
                      const sf::Texture& texture,
                      float moveSpeed = 100.f,
                      float maxLift = 100.f);

    void update(float deltaTime, bool buton1Pressed, bool buton2Pressed);

    // Returnează vectorul cu deplasarea platformei din ultimul update
    sf::Vector2f getMovementDelta() const;
};

#endif // PLATFORMA_SPECIALA_HPP